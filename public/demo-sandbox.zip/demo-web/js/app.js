const btn = document.getElementById("btn");
const canvas = document.getElementById("lienzo");
let n = 0;

btn.addEventListener("click", () => {
  n += 1;
  btn.textContent = `Pulsado ${n} ${n === 1 ? "vez" : "veces"}`;
  console.log("click", n);
  dibujar(n);
});

function dibujar(n) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < 7; i++) {
    const x = 20 + i * 36;
    const h = 20 + ((n * 13 + i * 29) % 55);
    const hue = 250 + i * 8;
    ctx.fillStyle = `hsl(${hue} 90% 65%)`;
    ctx.fillRect(x, canvas.height - 12 - h, 24, h);
  }
}

console.log("Demo del Sandbox lista ✔");
dibujar(1);
