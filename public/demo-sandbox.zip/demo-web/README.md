# Demo del Sandbox

Proyecto web estático de ejemplo para probar Prism AI Sandbox.

- `index.html` — entrada
- `css/style.css` — estilos (inlineado automático)
- `js/app.js` — lógica (inlineado automático)
- `assets/prisma.svg` — imagen local (data URL automática)

Edítalo, pulsa **Ejecutar** y mira la consola integrada.
