# Demo del Sandbox

Proyecto web estático de ejemplo para probar Prism AI Sandbox.

- `index.html` — entrada
- `css/style.css` — estilos (inlineado automático)
- `js/app.js` — lógica (inlineado automático)
- `assets/prisma.svg` — imagen local (data URL automática)

Edítalo, pulsa **Ejecutar** para verlo correr y **Revisar** para que el
Sandbox te diga qué habría que arreglar antes de subirlo a GitHub.
