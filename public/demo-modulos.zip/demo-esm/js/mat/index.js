export { suma } from "./ops.js";
