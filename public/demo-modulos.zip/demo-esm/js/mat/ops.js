import { MARCA } from "./constantes.js";

export function suma(a, b) {
  console.log("sumando en", MARCA);
  return a + b;
}
